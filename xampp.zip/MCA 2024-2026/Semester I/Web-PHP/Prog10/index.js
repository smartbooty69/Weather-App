$(document).ready(function() {
    $("#draggable").draggable();
    $("#datepicker").datepicker();
});
